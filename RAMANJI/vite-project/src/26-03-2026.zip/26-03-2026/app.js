import { configureStore } from '@reduxjs/toolkit'


import counterReducer from './reducer'

  export let store=configureStore({
    reducer:{
              count:counterReducer
    }
})



