import React, { Fragment, StrictMode } from 'react'

function A() {
  
  return (
    <div>
    <>
      <h1>the welcome react </h1>
            <h2>the welcome react </h2>
            <h3>the welcome react </h3>
      </>
the heddd
    <div>
      <h1>the welcome react </h1>
       <h2>the welcome react </h2>
        <h3>the welcome react </h3>
      </div>
      <StrictMode>
        <p>Lorem ipsum dolor sit amet consectetur.</p>
      </StrictMode>
      <Fragment>
        <p>the styling of web pages </p>
      </Fragment>

      
      </div>
     
  )
}

export default A
